/*
 * Alexander Burnette
 * 05/10/2021
 * Making a code to check for temperature.
 */
package temperaturecheck_burnettealexander;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;
public class TemperatureCheck_BurnetteAlexander 
{
    static ArrayList <String>  idList;
    public static void main(String[] args) 
    {
        JFrame f;
         idList = new ArrayList<>(); 
        String answer;
        f = new JFrame();
        do 
        {
           answerQuestions();
           answer = JOptionPane.showInputDialog(f, "Enter \"Yes\" to run another temperature: ");
        } while (answer.equalsIgnoreCase("yes"));
    }
    public static void answerQuestions() 
    {
       JFrame f;
       String input;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Verify if the person have a mask on. \n If the person does not have a mask, do not allow entry until mask is on.");
        input = JOptionPane.showInputDialog(f, "Can the person answer all the \"No\" to all the screening questions?");
        // <editor-fold defaultstate="collapsed" desc="Switch for yes or no">
        
        switch (input) 
        {
        case "Yes":
        case "yes":
        case "y":
            tempCheck();
            break;
        case "no":
        case "No":
        case "n":
            failTemperature();
            break;
        default:
          f = new JFrame();
           JOptionPane.showMessageDialog(f, "Invalid Choice");
            break;
        }
        // </editor-fold>
    }
    public static void tempCheck() 
    {
        JFrame f = null;
        int temp = Integer.parseInt(JOptionPane.showInputDialog(f, "Enter 1st Temperature."));
        if (temp >= 100.4) 
        {
            f = new JFrame();
            JOptionPane.showMessageDialog(f,"Hand over a copy of the FTCC's Covid-19 Campus Exposure Procedure."
                + "\n Give brochure titled \"What it is & How to protect yourself\""
                + "\n Please seat in the designated area."
                + "\n Wait three to five minutes for next test.");
            temp = Integer.parseInt(JOptionPane.showInputDialog(f, "Enter 2nd Temperature."));
            if (temp >= 100.4)
               failTemperature();
            else 
            {
                f = new JFrame();
                JOptionPane.showMessageDialog(f,"You are clear to go and collect an armband "
                    + "\n Wear armband at all times on campus."); 
            }
        } 
        else 
        {
            f = new JFrame();
            JOptionPane.showMessageDialog(f,"You are clear to go and collect an armband "
                    + "\n Wear armband at all times on campus."); 
        }
    }
    public static void failTemperature() 
    {
        String input;
        String answer;
        JFrame f = null;
        input = JOptionPane.showInputDialog(f,"Please enter if you are \n 1. Faculity \n 2. Student \n 3. Staff \n 4. Visitor \n 5. High School");
        switch (input) 
            //<editor-fold defaultstate="collapsed" desc="Switch for what the user choose">
        {
            case "Faculity":
            case "faculity":
            case "1":
                JOptionPane.showMessageDialog(f,"Contact your immedaite supervisor. \n Contact the College's Covid Coordinator Damita Reed."
                        + "\n Leave the campus for everyone's saftey.");
                break;
                
            case "Student":
            case "student":
            case "2":
                JOptionPane.showMessageDialog(f,"Contact your instuctors and arrange for make-up assignments."
                        + "\n Leave the campus for everyone's saftey.");
                break;
                
            case "staff":
            case "Staff":
            case "3":
                JOptionPane.showMessageDialog(f,"Contact your Immedaite supervisor. \n Contact the College's Covid Coordinator Damita Reed."
                        + "\n Leave the campus for everyone's safety.");
                break;
                
            case "Visitor":
            case "visitor":
            case "4":
                JOptionPane.showMessageDialog(f,"Leave the campus and contact the College's COVID Corrdinator.");
                break;
                
            case "High school":
            case "High School":
            case "5":
            case "high school":
                JOptionPane.showMessageDialog(f,"Leave the campus. \n Contact your instructors and arrange for makeup assignments. \n"
                        + "Contact the College's COVID Corrdinator. \n Contact your High School and inform them.");
                break;
                
            default:
                JOptionPane.showMessageDialog(f, "Invalid Choice");
                break;
                // </editor-fold>
        }
        answer = JOptionPane.showInputDialog(f, "Do you want add an ID# to list Temerpature?");
        if(answer.equalsIgnoreCase("yes"))
        {
            recordNumbers();
        }
    }
     public static void recordNumbers() 
    {
        String id;
        id = JOptionPane.showInputDialog("Enter ID to List");
        idList.add(id);
        Collections.sort(idList);
        String str = "-------------------------\n\"High Temperature List\" count: " + idList.size()
         + "\n-------------------------\n";         
            for (int i = 0; i < idList.size(); i++)
                str += idList.get(i) + "\n";
                
        JOptionPane.showMessageDialog(null, str);
    }
    public static void showPsuedocode()
    {
        System.out.println("User will see if mask is present.");
        System.out.println("User will be asked if they can answer \"No\" to all questions.");
        System.out.println("If user can't they will be asked of thier role and the message will follow");
        System.out.println("If they can, continue program as normal.");
        System.out.println("User's temperature gets inputed in the code.");
        System.out.println("If User's temperature is lower than 100.4, a display will prompt \"You are clear to go."
                + "Collect your armband.\".");
        System.out.println("If User's temperature higher than 100.4, prompt will appear asking to wait for 3-5 minutes.");
        System.out.println("A second display will ask for the User's tempature.");
        System.out.println("If User's temperature is lower than 100.4, the will pass through with an armband.");
        System.out.println("If User's temperature is higher thatn 100.4, they will get a different prompt.");
        System.out.println("They prompt will ask if they are faculty or student.");
        System.out.println("If faculty, A display will say \"Contact your immedaite supervisor \n Contact the College's Covid Coordinator Damita Reed"
                               + "\n Leave the campus for everyone's saftey\".");
        System.out.println("If student, A display will say \"Leave the campus for everyone's safety. Contact your instructors"
                + "and let them know, and arrange for make-up assignments\".");
        System.out.println("If Staff, A display say \"Contact your Immedaite supervisor \n  Contact the College's Covid Coordinator Damita Reed "
                               + "\n Leave the campus for everyone's safety\".");
        System.out.println("If Visitor, A display say \"Leave the campus and contact the College's COVID Corrdinator\".");
        System.out.println("If High School, a display will say \"Leave campus. contact instructors for assignments. "
                + "Contact the College's Covid Corridenator. Contact the high school\"");
        System.out.println("A display will as if you want to add an ID to the Temperature list");
        System.out.println("If yes, the user will add the id to the hi-temp list");
        System.out.println("Once the id is added, a display will appear with the id number and others");
        System.out.println("Once the user hits ok, they will be asked to run another temperature to continue or no to cancel/");
    }   
}